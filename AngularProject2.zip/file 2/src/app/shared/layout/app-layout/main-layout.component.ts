import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-main-layout',
    templateUrl: './main-layout.component.html',
    styles: []
})
export class MainLayoutComponent implements OnInit {

    constructor() { 
        console.log('ramu')
    }

    ngOnInit() {
    }

}
