
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-parent',
    templateUrl: './parent.component.html'
})
export class ParentComponent {

}